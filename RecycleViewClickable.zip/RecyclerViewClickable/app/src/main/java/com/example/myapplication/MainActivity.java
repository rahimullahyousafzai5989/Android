package com.example.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.DividerItemDecoration;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements MyRecyclerViewAdapter.IMyItemClickListener
{
    MyRecyclerViewAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ArrayList<String> names = new ArrayList<>();
        names.add("Item 1");
        names.add("Item 2");
        names.add("Item 3");
        names.add("Item 4");
        names.add("Item 5");
        names.add("Item 6");
        names.add("Item 7");
        names.add("Item 8");
        names.add("Item 9");
        names.add("Item 10");
        names.add("Item 11");
        names.add("Item 12");
        names.add("Item 13");
        names.add("Item 14");
        names.add("Item 15");
        names.add("Item 16");
        names.add("Item 17");
        names.add("Item 18");
        names.add("Item 19");
        names.add("Item 20");

        RecyclerView recyclerView = findViewById(R.id.recyclerView1);

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(linearLayoutManager);

        /// Divider code ///
        DividerItemDecoration dividerItemDecoration = new DividerItemDecoration(recyclerView.getContext(), linearLayoutManager.getOrientation());
        recyclerView.addItemDecoration(dividerItemDecoration);
        //================

        adapter = new MyRecyclerViewAdapter(this, names);
        adapter.setClickListener(this);
        recyclerView.setAdapter(adapter);

    }

    @Override
    public void onMyItemClick(View view, int position)
    {
        Toast.makeText(this, "You clicked: " + adapter.getItem(position) + " on row " + position, Toast.LENGTH_SHORT).show();
    }
}
