package com.example.myapplication;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.List;

public class MyRecyclerViewAdapter  extends RecyclerView.Adapter<MyRecyclerViewAdapter.ViewHolder>
{
    private List<String> mData;
    private LayoutInflater mInflater;
    private IMyItemClickListener mClickListener;

    public MyRecyclerViewAdapter(Context context, List<String> data)
    {
        this.mInflater = LayoutInflater.from(context);
        this.mData = data;

    }

    // inflates the row layout xml when required
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i)
    {
        View view = mInflater.inflate(R.layout.recycler_row, viewGroup, false);
        return new ViewHolder(view);
    }

    // binds the data to each row in textview
    @Override
    public void onBindViewHolder(@NonNull ViewHolder viewHolder, int i)
    {
        String name = mData.get(i);
        viewHolder.myTextView.setText(name);
    }

    @Override
    public int getItemCount()
    {
        return mData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener
    {
        TextView myTextView;

        public ViewHolder(@NonNull View itemView)
        {
            super(itemView);
            myTextView = itemView.findViewById(R.id.textViewName);
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v)
        {
            if(mClickListener != null)
                mClickListener.onMyItemClick(v, getAdapterPosition());
        }
    }

    String getItem(int id)
    {
        return mData.get(id);
    }
    // allows click events to be caught
    void setClickListener(IMyItemClickListener itemClickListener)
    {
        this.mClickListener = itemClickListener;
    }

    // parent activity will implement this method to respond to click events

    public interface IMyItemClickListener
    {
        void onMyItemClick(View view, int position);
    }
}
